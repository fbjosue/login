<?php
include "include/conexion.php";
$mensajedos = "";
$tipoAlertados = "";

// validación para restablecer la contraseña si el email existe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = isset($_POST["Email"]) ? mysqli_real_escape_string($conecta, $_POST["Email"]) : "";
  $password = isset($_POST["Password"]) ? mysqli_real_escape_string($conecta, $_POST["Password"]) : "";

  // Verificar si el correo electrónico existe
  $emailExistenteQuery = "SELECT * FROM usuarios WHERE Email='$email'";
  $emailExistenteResult = mysqli_query($conecta, $emailExistenteQuery);

  if ($emailExistenteResult && mysqli_num_rows($emailExistenteResult) == 1) {
  
    // Cifrar la nueva contraseña 
    $contraseñaCifrada = md5($password);

    // Actualizar la contraseña en la base de datos
    $actualizarContraseñaQuery = "UPDATE usuarios SET Password='$contraseñaCifrada' WHERE Email='$email'";
    $actualizarContraseñaResult = mysqli_query($conecta, $actualizarContraseñaQuery);

    if ($actualizarContraseñaResult) {
      $mensajedos = "Contraseña actualizada correctamente. La nueva contraseña es: $password";
      $tipoAlertados = "success";
      //  después de 5 segundos se va a la página de inicio de sesión
      echo '<meta http-equiv="refresh" content="5;url=index.php">';
    } else {
      $mensajedos = "Error al actualizar la contraseña. Inténtalo de nuevo más tarde.";
      $tipoAlertados = "danger";
    }
  } else {
    $mensajedos = "Error: No se encontró ninguna cuenta asociada con el correo electrónico proporcionado.";
    $tipoAlertados = "danger";
  }

  mysqli_close($conecta);
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- estilos de css -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- <link rel="stylesheet" href="css/dark.css"> -->
  <link rel="stylesheet" href="css/pace.css">
  <link rel="stylesheet" href="css/estilos.css">
  <!-- jquery -->
  <script src="js/jquery.js"></script>
  <!-- cdn iconos -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
  <title>Inicio de sistema | RIAC</title>
</head>

<body class="fondo">
  <div class="container">
    <div class="justify-content-center mt-5">
      <div class="row mt-3 text-center">
        <div class="col-sm-12 col-md-12 col-lg-12 text-center">
          <strong>
            <h1 class="text-center ">Bienvenido al<span class="text-info"> Restablecimiento de Contraseña</span></h1>
          </strong>
          
          <div class="row mt-2  justify-content-center mt-5">
            <div class="col-sm-6 col-md-6 col-lg-6">
              <div>
                <div class="row  justify-content-center">
                  <img src="img/LogoRiac.png" alt="Riac" style="width: 250px;" class="img-fluid">
                </div>
                <br>
                <center>
                <a href="index.php" class="text-white text-decoration-none">
                      <i class="bi bi-arrow-left-circle"></i> Regresar
                    </a>
                </center>
             
                <?php if (!empty($mensajedos)): ?>
            <div class="alert alert-<?php echo $tipoAlertados; ?> mt-3" role="alert">
              <?php echo $mensajedos; ?>
            </div>
          <?php endif; ?>

                
                  <!-- Muestra el formulario solo si no hay mensaje o el tipo de alerta no es 'success' -->
                  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" autocomplete="off"
                    class="needs-validation" novalidate>
                    <div class="row mt-2 justify-content-center">
                      <div class="col-sm-8 col-md-8 col-lg-8">
                        <input type="text" name="Email" id="Email" placeholder="Email"
                          class="form-control rounded-pill border-info" autocomplete="off" required />
                        <div class="invalid-feedback">Por favor ingresa tu Email.</div>
                      </div>
                    </div>
                    <div class="row mt-2 mb-2 justify-content-center">
                      <div class="col-sm-8 col-md-8 col-lg-8">
                        <input type="password" name="Password" id="pass" placeholder="Nueva Contraseña"
                          class="form-control rounded-pill border-info" autocomplete="off" required />
                        <div class="invalid-feedback">Por favor ingresa tu Password.</div>
                      </div>
                    </div>
                    <div class="row mt-1 justify-content-center">

                      <div class="col-sm-6 col-md-6 col-lg-6">
                        <div class="form-check form-switch">
                          <input class="form-check-input" type="checkbox" id="ver" onclick="verpass(this);">
                          <label class="form-check-label" for="ver">Ver Password</label>
                        </div>
                      </div>
                    </div>
                    <div class="row mt-4 mb-2 justify-content-center">
                      <div class="col-sm-8 col-md-8 col-lg-8">
                        <div class="d-grid gap-2">
                          <input type="submit" value="Restablecer Contraseña" name="btn-ingresar" id="btn-ingreso"
                            class="btn btn-success rounded-pill">
                        </div>
                      </div>
                    </div>
                  </form>
                
              </div>
            </div>
          </div>
          <div class="row mt-2 mb-4 justify-content-center">
            <div class="col-sm-12 col-lg-12 col-md-12">
              <a href="#" target="_blank" class="text-decoration-none text-success me-3">
                <i class="bi bi-facebook"></i>
              </a>
              <a href="#" target="_blank" class="text-decoration-none text-success me-3">
                <i class="bi bi-instagram"></i>
              </a>
              <a href="#" target="_blank" class="text-decoration-none text-success">
                <i class="bi bi-envelope"></i>
              </a>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
  

  <script src="js/bootstrap.min.js"></script>
  <script src="js/dark-mode.js"></script>
  <script src="js/pace.js"></script>
  <script>
    function verpass(cb) {
      if (cb.checked)
        $('#pass').attr("type", "text");
      else
        $('#pass').attr("type", "password");
    }
  </script>
  <script>
    (function () {
      'use strict'

      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.querySelectorAll('.needs-validation')

      // Loop over them and prevent submission
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }

            form.classList.add('was-validated')
          }, false)
        })
    })()
  </script>
 
</body>

</html>

<?php
$host = "localhost";
$user = "root";
$bd = "riac";
$password = "";
$conecta = mysqli_connect($host,$user,$password,$bd);
if($conecta->connect_error){
  die('Error al conectar la base de datos'.$conecta->connect_error);
}else{
  echo "Conexión exitosa";
}
 ?>
<?php
include "include/conexion.php";

$mensaje = "";
$tipoAlerta = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $usuario = mysqli_real_escape_string($conecta, $_POST["UserName"]);
  $password = mysqli_real_escape_string($conecta, $_POST["Password"]);

  // Cifrar la contraseña usando md5
  $password = md5($password);

  // Verificar si el usuario existe
  $usuarioExistenteQuery = "SELECT * FROM usuarios WHERE UserName='$usuario'";
  $usuarioExistenteResult = mysqli_query($conecta, $usuarioExistenteQuery);

  if (mysqli_num_rows($usuarioExistenteResult) == 1) {
    // El usuario existe, proceder con la validación de la contraseña cifrada
    $query = "SELECT * FROM usuarios WHERE UserName='$usuario' AND Password='$password'";
    $result = mysqli_query($conecta, $query);

    if (mysqli_num_rows($result) == 1) {
      $row = mysqli_fetch_assoc($result);
      $mensaje = "Bienvenido, Usuario: " . $row['UserName'];
      $tipoAlerta = "success";
    } else {
      $mensaje = "Error de inicio de sesión. Contraseña incorrecta.";
      $tipoAlerta = "danger";
    }
  } else {
    $mensaje = "Error de inicio de sesión. Usuario no encontrado.";
    $tipoAlerta = "danger";
  }

  mysqli_close($conecta);
}

// Configurar la zona horaria de nuestro servidor
ini_set('date.timezone', 'America/Mexico_City');

$hora_actual = date('H');
switch (true) {
  case ($hora_actual >= 5 && $hora_actual < 12):
    $saludo = '¡Buenos días!';
    $icono = 'bi-sun';
    break;
  case ($hora_actual >= 12 && $hora_actual < 18):
    $saludo = '¡Buenas tardes!';
    $icono = 'bi-brightness-alt-high';
    break;
  default:
    $saludo = '¡Buenas noches!';
    $icono = 'bi-moon';
    break;
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- estilos de css -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- <link rel="stylesheet" href="css/dark.css"> -->
  <link rel="stylesheet" href="css/pace.css">
  <link rel="stylesheet" href="css/estilos.css">
  <!-- jquery -->
  <script src="js/jquery.js"></script>
  <!-- cdn iconos -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
  <title>Inicio de sistema | RIAC</title>
</head>

<body class="fondo">
  <div class="container">
    <div class="justify-content-center mt-5">
      <div class="row mt-3 text-center">
        <div class="col-sm-12 col-md-12 col-lg-12 text-center">
          <strong>
            <h1 class="text-center ">Bienvenido al<span class="text-info"> Inicio de sesión</span></h1>
          </strong>
          <h4>
            <?php echo $saludo; ?> <i class="bi <?php echo $icono; ?>"></i>
          </h4>
          <div class="row mt-2  justify-content-center mt-5">
            <div class="col-sm-6 col-md-6 col-lg-6">
              <div>
                <div class="row  justify-content-center">
                  <img src="img/LogoRiac.png" alt="Riac" style="width: 250px;" class="img-fluid">
                </div>
                <div class="row ">
                  <div class="col-sm-4 col-md-4 col-lg-4"></div>
                  <div class="col-sm-8 col-md-8 col-lg-8">
                    <a href="restaurar-contrasena.php" class="text-white text-decoration-none">
                      <i class="bi bi-key"></i> Perdiste tu Password
                    </a>

                  </div>
                </div>
                <?php if (!empty($mensaje)): ?>
                  <div class="alert alert-<?php echo $tipoAlerta; ?> mt-3" role="alert">
                    <?php echo $mensaje; ?>
                  </div>
                <?php endif; ?>

                <?php if (empty($mensaje) || $tipoAlerta !== 'success'): ?>
                  <!-- Muestra el formulario solo si no hay mensaje o el tipo de alerta no es 'success' -->
                  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" autocomplete="off"
                    class="needs-validation" novalidate>
                    <div class="row mt-2 justify-content-center">
                      <div class="col-sm-8 col-md-8 col-lg-8">
                        <input type="text" name="UserName" id="UserName" placeholder="Usuario"
                          class="form-control rounded-pill border-info" autocomplete="off" required />
                        <div class="invalid-feedback">Por favor ingresa tu Usuario.</div>
                      </div>
                    </div>
                    <div class="row mt-2 mb-2 justify-content-center">
                      <div class="col-sm-8 col-md-8 col-lg-8">
                        <input type="password" name="Password" id="pass" placeholder="Contraseña"
                          class="form-control rounded-pill border-info" autocomplete="off" required />
                        <div class="invalid-feedback">Por favor ingresa tu password.</div>
                      </div>
                    </div>
                    <div class="row mt-1 justify-content-center">

                      <div class="col-sm-6 col-md-6 col-lg-6">
                        <div class="form-check form-switch">
                          <input class="form-check-input" type="checkbox" id="ver" onclick="verpass(this);">
                          <label class="form-check-label" for="ver">Ver Password</label>
                        </div>
                      </div>
                    </div>
                    <div class="row mt-4 mb-2 justify-content-center">
                      <div class="col-sm-8 col-md-8 col-lg-8">
                        <div class="d-grid gap-2">
                          <input type="submit" value="Ingresar" name="btn-ingresar" id="btn-ingreso"
                            class="btn btn-success rounded-pill">
                        </div>
                      </div>
                    </div>
                  </form>
                  <?php else: ?>
                    <div>
        
        <a href="include/cerrar-sesion.php" class="btn btn-danger">
            Cerrar Sesión
            <i class="bi bi-box-arrow-right"></i> <!-- Icono de cerrar sesión de Bootstrap -->
        </a>
    </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="row mt-2 mb-4 justify-content-center">
            <div class="col-sm-12 col-lg-12 col-md-12">
              <a href="#" target="_blank" class="text-decoration-none text-success me-3">
                <i class="bi bi-facebook"></i>
              </a>
              <a href="#" target="_blank" class="text-decoration-none text-success me-3">
                <i class="bi bi-instagram"></i>
              </a>
              <a href="#" target="_blank" class="text-decoration-none text-success">
                <i class="bi bi-envelope"></i>
              </a>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
  

  <script src="js/bootstrap.min.js"></script>
  <script src="js/dark-mode.js"></script>
  <script src="js/pace.js"></script>
  <script>
    function verpass(cb) {
      if (cb.checked)
        $('#pass').attr("type", "text");
      else
        $('#pass').attr("type", "password");
    }
  </script>
  <script>
    (function () {
      'use strict'

      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.querySelectorAll('.needs-validation')

      // Loop over them and prevent submission
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }

            form.classList.add('was-validated')
          }, false)
        })
    })()
  </script>
</body>

</html>
// funcion para desabilitar los input de expediente
 window.onload=function() {
    document.getElementById('NomDis').disabled = true;
    document.getElementById('FechaDis').disabled = true;
    document.getElementById('TuserDis').disabled = true;
    document.getElementById('Ncredencial').disabled = true;
    document.getElementById('Nbanco').disabled = true;
    document.getElementById('Numcuenta').disabled = true;
    document.getElementById('Tpago').disabled = true;
    document.getElementById('Solicitante').disabled = true;
  }
  
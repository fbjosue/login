-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para riac
CREATE DATABASE IF NOT EXISTS `riac` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `riac`;

-- Volcando estructura para tabla riac.accion_realizada
CREATE TABLE IF NOT EXISTS `accion_realizada` (
  `Id_Accion_Realizada` int NOT NULL AUTO_INCREMENT,
  `Observaciones` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`Id_Accion_Realizada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.accion_realizada: ~0 rows (aproximadamente)

-- Volcando estructura para tabla riac.carreras
CREATE TABLE IF NOT EXISTS `carreras` (
  `Id_Carrera` int NOT NULL AUTO_INCREMENT,
  `Nombre_Carrera` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Carrera`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.carreras: ~4 rows (aproximadamente)
INSERT IGNORE INTO `carreras` (`Id_Carrera`, `Nombre_Carrera`) VALUES
	(1, 'Informatica'),
	(2, 'Contabilidad'),
	(3, 'Alimentos y bebidas'),
	(4, 'Hospitalidad Turistica');

-- Volcando estructura para tabla riac.estados
CREATE TABLE IF NOT EXISTS `estados` (
  `Id_Estado` int NOT NULL AUTO_INCREMENT,
  `Nombre_Estado` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Estado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.estados: ~3 rows (aproximadamente)
INSERT IGNORE INTO `estados` (`Id_Estado`, `Nombre_Estado`) VALUES
	(1, 'Mexico'),
	(2, 'Queretaro'),
	(3, 'Puebla');

-- Volcando estructura para tabla riac.estatus
CREATE TABLE IF NOT EXISTS `estatus` (
  `Id_Estatus` int NOT NULL AUTO_INCREMENT,
  `Nombre_Estatus` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Estatus`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.estatus: ~2 rows (aproximadamente)
INSERT IGNORE INTO `estatus` (`Id_Estatus`, `Nombre_Estatus`) VALUES
	(1, 'Activo'),
	(2, 'Baja');

-- Volcando estructura para tabla riac.expedientes
CREATE TABLE IF NOT EXISTS `expedientes` (
  `Id_Expediente` int NOT NULL AUTO_INCREMENT,
  `Matricula` int NOT NULL,
  `Calle` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
  `Colonia` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
  `Numero` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
  `CP` int NOT NULL,
  PRIMARY KEY (`Id_Expediente`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.expedientes: ~14 rows (aproximadamente)
INSERT IGNORE INTO `expedientes` (`Id_Expediente`, `Matricula`, `Calle`, `Colonia`, `Numero`, `CP`) VALUES
	(1, 1234561941, 'Calle Ficticia 1', 'Colonia Ficticia 1', '123', 53400),
	(2, 2147483647, 'Calle Ficticia 2', 'Colonia Ficticia 2', '456', 53600),
	(3, 2147483647, 'Calle Ficticia 3', 'Colonia Ficticia 3', '789', 53200),
	(4, 1111111941, 'Calle Ficticia 4', 'Colonia Ficticia 4', '101', 53800),
	(5, 2147483647, 'Calle Ficticia 5', 'Colonia Ficticia 5', '111', 53000),
	(6, 2147483647, 'Calle Ficticia 6', 'Colonia Ficticia 6', '222', 53100),
	(7, 2147483647, 'Calle Ficticia 7', 'Colonia Ficticia 7', '333', 53300),
	(8, 2147483647, 'Calle Ficticia 8', 'Colonia Ficticia 8', '444', 53700),
	(9, 2147483647, 'Calle Ficticia 9', 'Colonia Ficticia 9', '555', 53900),
	(10, 2147483647, 'Calle Ficticia 10', 'Colonia Ficticia 10', '666', 53500),
	(11, 2147483647, 'Calle Ficticia 11', 'Colonia Ficticia 11', '777', 53450),
	(12, 1231231941, 'Calle Ficticia 12', 'Colonia Ficticia 12', '888', 53460),
	(13, 2147483647, 'Calle Ficticia 13', 'Colonia Ficticia 13', '999', 53470),
	(14, 2118701941, 'Calle Ficticia 14', 'Colonia Ficticia 14', '123', 53480);

-- Volcando estructura para tabla riac.genero
CREATE TABLE IF NOT EXISTS `genero` (
  `Id_Genero` int NOT NULL AUTO_INCREMENT,
  `Genero` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Genero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.genero: ~2 rows (aproximadamente)
INSERT IGNORE INTO `genero` (`Id_Genero`, `Genero`) VALUES
	(1, 'Hombre'),
	(2, 'Mujer');

-- Volcando estructura para tabla riac.grupos
CREATE TABLE IF NOT EXISTS `grupos` (
  `Id_Grupo` int NOT NULL AUTO_INCREMENT,
  `Nombre_Grupo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Grupo`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.grupos: ~36 rows (aproximadamente)
INSERT IGNORE INTO `grupos` (`Id_Grupo`, `Nombre_Grupo`) VALUES
	(1, '101'),
	(2, '102'),
	(3, '103'),
	(4, '104'),
	(5, '105'),
	(6, '106'),
	(7, '201'),
	(8, '202'),
	(9, '203'),
	(10, '204'),
	(11, '205'),
	(12, '206'),
	(13, '301'),
	(14, '302'),
	(15, '303'),
	(16, '304'),
	(17, '305'),
	(18, '306'),
	(19, '401'),
	(20, '402'),
	(21, '403'),
	(22, '404'),
	(23, '405'),
	(24, '406'),
	(25, '501'),
	(26, '502'),
	(27, '503'),
	(28, '504'),
	(29, '505'),
	(30, '506'),
	(31, '601'),
	(32, '602'),
	(33, '603'),
	(34, '604'),
	(35, '605'),
	(36, '606');

-- Volcando estructura para tabla riac.informes
CREATE TABLE IF NOT EXISTS `informes` (
  `Id_Informe` int NOT NULL AUTO_INCREMENT,
  `Id_Modulo` int NOT NULL,
  `N_Tutor` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Id_Grupo` int NOT NULL,
  `Id_Carrera` int NOT NULL,
  `Id_Turno` int NOT NULL,
  `Id_Mes` int NOT NULL,
  `Fecha_Entrega` date NOT NULL,
  `Id_Usuario` int NOT NULL,
  `Id_Genero` int NOT NULL,
  `Id_Problematica` int NOT NULL,
  `Observacion` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Id_Accion_Realizada` int NOT NULL,
  `Sugerencia` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`Id_Informe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.informes: ~0 rows (aproximadamente)

-- Volcando estructura para tabla riac.meses
CREATE TABLE IF NOT EXISTS `meses` (
  `Id_Mes` int NOT NULL AUTO_INCREMENT,
  `Nombre_Mes` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Mes`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.meses: ~12 rows (aproximadamente)
INSERT IGNORE INTO `meses` (`Id_Mes`, `Nombre_Mes`) VALUES
	(1, 'Enero'),
	(2, 'Febrero'),
	(3, 'Marzo'),
	(4, 'Abril'),
	(5, 'Mayo'),
	(6, 'Junio'),
	(7, 'Julio'),
	(8, 'Agosto'),
	(9, 'Septiembre'),
	(10, 'Octubre'),
	(11, 'Noviembre'),
	(12, 'Diciembre');

-- Volcando estructura para tabla riac.modulos
CREATE TABLE IF NOT EXISTS `modulos` (
  `Id_Modulo` int NOT NULL AUTO_INCREMENT,
  `Nombre_Modulo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Modulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.modulos: ~0 rows (aproximadamente)

-- Volcando estructura para tabla riac.motivo_atencion
CREATE TABLE IF NOT EXISTS `motivo_atencion` (
  `Id_Motivo_Atencion` int NOT NULL AUTO_INCREMENT,
  `Nombre_Motivo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Motivo_Atencion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.motivo_atencion: ~0 rows (aproximadamente)

-- Volcando estructura para tabla riac.municipios
CREATE TABLE IF NOT EXISTS `municipios` (
  `Id_Municipio` int NOT NULL AUTO_INCREMENT,
  `Nombre_Municipio` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Municipio`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.municipios: ~2 rows (aproximadamente)
INSERT IGNORE INTO `municipios` (`Id_Municipio`, `Nombre_Municipio`) VALUES
	(1, 'Naucalpan'),
	(2, 'Tlanepantla');

-- Volcando estructura para tabla riac.planteles
CREATE TABLE IF NOT EXISTS `planteles` (
  `Id_Plantel` int NOT NULL AUTO_INCREMENT,
  `Nombre_Plantel` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Email_Plantel` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Telefono_Plantel` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Plantel`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.planteles: ~2 rows (aproximadamente)
INSERT IGNORE INTO `planteles` (`Id_Plantel`, `Nombre_Plantel`, `Email_Plantel`, `Telefono_Plantel`) VALUES
	(1, 'Naucalpan1', 'cn_naucalpan1@conalepmex.edu.mx', '55-53-12-22-77'),
	(2, 'Naucalpan2', 'cn_naucalpan2@conalepmex.edu.mx', '55-53-12-43-92');

-- Volcando estructura para tabla riac.problematicas
CREATE TABLE IF NOT EXISTS `problematicas` (
  `Id_Problematica` int NOT NULL AUTO_INCREMENT,
  `Inasistencias` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Bajo_Rendimiento` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Comportamiento` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Estudiante_NEE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`Id_Problematica`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.problematicas: ~0 rows (aproximadamente)

-- Volcando estructura para tabla riac.semestres
CREATE TABLE IF NOT EXISTS `semestres` (
  `Id_Semestre` int NOT NULL AUTO_INCREMENT,
  `Nombre_Semestre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Semestre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.semestres: ~6 rows (aproximadamente)
INSERT IGNORE INTO `semestres` (`Id_Semestre`, `Nombre_Semestre`) VALUES
	(1, 'Primero'),
	(2, 'Segundo'),
	(3, 'Tercero'),
	(4, 'Cuarto'),
	(5, 'Quinto'),
	(6, 'Sexto');

-- Volcando estructura para tabla riac.turno
CREATE TABLE IF NOT EXISTS `turno` (
  `Id_Turno` int NOT NULL AUTO_INCREMENT,
  `Turno` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_Turno`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.turno: ~0 rows (aproximadamente)
INSERT IGNORE INTO `turno` (`Id_Turno`, `Turno`) VALUES
	(1, 'Matutino'),
	(2, 'Vespertino');

-- Volcando estructura para tabla riac.tusuarios
CREATE TABLE IF NOT EXISTS `tusuarios` (
  `Id_TUsuario` int NOT NULL AUTO_INCREMENT,
  `Nombre_TUsuario` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Descripcion` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id_TUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.tusuarios: ~6 rows (aproximadamente)
INSERT IGNORE INTO `tusuarios` (`Id_TUsuario`, `Nombre_TUsuario`, `Descripcion`) VALUES
	(1, 'Sistemas', 'SuperUsuario'),
	(2, 'Administrativos', 'UsuarioTecnico'),
	(3, 'Docentes', 'UsuarioTecnico'),
	(4, 'Tutor_F', 'UsuarioFinal'),
	(5, 'Orientador', 'UsuarioTecnico'),
	(6, 'Alumnos', 'UsuarioFinal');

-- Volcando estructura para tabla riac.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `Id_Usuario` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ApellidoP` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ApellidoM` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Telefono` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `UserName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Online` int NOT NULL,
  `Img_Usuario` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Id_Plantel` int NOT NULL,
  `Id_TUsuario` int NOT NULL,
  `Id_Estatus` int NOT NULL,
  `Id_Expediente` int NOT NULL,
  PRIMARY KEY (`Id_Usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla riac.usuarios: ~13 rows (aproximadamente)
INSERT IGNORE INTO `usuarios` (`Id_Usuario`, `Nombre`, `ApellidoP`, `ApellidoM`, `Telefono`, `Email`, `Password`, `UserName`, `Online`, `Img_Usuario`, `Id_Plantel`, `Id_TUsuario`, `Id_Estatus`, `Id_Expediente`) VALUES
	(1, 'LUDWIN ', 'FRANCO', 'VALDES', '123456789', 'ludwin.alexis@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'ludwin_alexis', 0, '', 1, 1, 1, 1),
	(2, 'JOSUE', 'FLORES', 'BENITEZ', '987654321', 'abi.josue@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'abi_josue', 0, '', 1, 1, 1, 2),
	(3, 'ARMANDO', 'GABRIEL', 'HERNANDEZ', '555555555', 'armando.gabriel@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'armando_gabriel', 0, '', 4, 4, 1, 3),
	(4, 'DANNA', 'LEONIDES', 'CRUZ', '111111111', 'danna.leonides@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'danna_leonides', 0, '', 1, 1, 1, 4),
	(5, 'NAOMI', 'LEON', 'CORDERO', '999999999', 'naomi.leon@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'naomi_leon', 0, '', 2, 1, 1, 5),
	(6, 'ISAIN', 'NAJAR', 'YAUTENTZI', '777777777', 'isain.najar@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'isain_najar', 0, '', 1, 1, 1, 6),
	(7, 'LUIS', 'JUAREZ', 'ALCANTARA', '444444444', 'luis.juarez@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'luis_juarez', 0, '', 4, 1, 1, 7),
	(8, 'CARLOS', 'HUERTA', 'GALVAN', '666666666', 'carlos.huerta@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'carlos_huerta', 0, '', 1, 1, 1, 8),
	(9, 'JOHAN', 'MUÑOZ', 'MAYEN', '333333333', 'johan.munoz@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'johan_munoz', 0, '', 3, 1, 1, 9),
	(10, 'GABRIELA', 'HIDALGO', 'CALDERON', '222222222', 'gabriela.hidalgo@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'gabriela_hidalgo', 0, '', 1, 1, 1, 10),
	(11, 'ZOE', 'RODRIGUEZ', 'ANDRADE', '888888888', 'zoe.rodriguez@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'zoe_rodriguez', 0, '', 1, 1, 1, 11),
	(12, 'ALINE', 'HERNANDEZ', 'DANIEL', '123123123', 'aline.hernandez@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'aline_hernandez', 0, '', 1, 1, 1, 12),
	(13, 'HECTOR', 'NICANOR', 'NARVAEZ', '555123555', 'hector.nicanor@conalepmex.edu.mx', '25d55ad283aa400af464c76d713c07ad', 'hector_nicanor', 0, '', 1, 1, 1, 13);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
